<ul>
    <li><a href="home.php" title="Home">Home</a></li>
    <li><a href="cannon.php" title="Cannon">Cannon</a></li>
    <li><a href="explosive.php" title="Explosive">Explosive</a></li>
    <li><a href="misc.php" title="Misc">Misc</a></li>
    <li><a href="rocket.php" title="Rocket">Rocket</a></li>
    <li><a href="trap.php" title="Trap">Trap</a></li>
</ul>